So unfortunately i've not been really productive with this in the past few weeks. 
These are the rips I did before I started using the lines, in game they line up on
pawns but are way too smol in comparison to the originals, 
so I started a standard to use to keep horns growing out of roughly the same spots, postion wise. 
it's really not much but hopefully it helps.
